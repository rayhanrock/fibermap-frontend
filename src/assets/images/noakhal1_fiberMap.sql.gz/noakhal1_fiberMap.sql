-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: noakhal1_fiberMap
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add cable',6,'add_cable'),(22,'Can change cable',6,'change_cable'),(23,'Can delete cable',6,'delete_cable'),(24,'Can view cable',6,'view_cable'),(25,'Can add marker',7,'add_marker'),(26,'Can change marker',7,'change_marker'),(27,'Can delete marker',7,'delete_marker'),(28,'Can view marker',7,'view_marker'),(29,'Can add user',8,'add_userprofile'),(30,'Can change user',8,'change_userprofile'),(31,'Can delete user',8,'delete_userprofile'),(32,'Can view user',8,'view_userprofile'),(33,'Can add core',9,'add_core'),(34,'Can change core',9,'change_core'),(35,'Can delete core',9,'delete_core'),(36,'Can view core',9,'view_core'),(37,'Can add connection',10,'add_connection'),(38,'Can change connection',10,'change_connection'),(39,'Can delete connection',10,'delete_connection'),(40,'Can view connection',10,'view_connection'),(41,'Can add gpon',11,'add_gpon'),(42,'Can change gpon',11,'change_gpon'),(43,'Can delete gpon',11,'delete_gpon'),(44,'Can view gpon',11,'view_gpon'),(45,'Can add client',12,'add_client'),(46,'Can change client',12,'change_client'),(47,'Can delete client',12,'delete_client'),(48,'Can view client',12,'view_client'),(49,'Can add pop',13,'add_pop'),(50,'Can change pop',13,'change_pop'),(51,'Can delete pop',13,'delete_pop'),(52,'Can view pop',13,'view_pop'),(53,'Can add reseller',14,'add_reseller'),(54,'Can change reseller',14,'change_reseller'),(55,'Can delete reseller',14,'delete_reseller'),(56,'Can view reseller',14,'view_reseller'),(57,'Can add tj box',15,'add_tjbox'),(58,'Can change tj box',15,'change_tjbox'),(59,'Can delete tj box',15,'delete_tjbox'),(60,'Can view tj box',15,'view_tjbox'),(61,'Can add Token',16,'add_token'),(62,'Can change Token',16,'change_token'),(63,'Can delete Token',16,'delete_token'),(64,'Can view Token',16,'view_token'),(65,'Can add token',17,'add_tokenproxy'),(66,'Can change token',17,'change_tokenproxy'),(67,'Can delete token',17,'delete_tokenproxy'),(68,'Can view token',17,'view_tokenproxy');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authtoken_token`
--

DROP TABLE IF EXISTS `authtoken_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authtoken_token` (
  `key` varchar(40) NOT NULL,
  `created` datetime(6) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `authtoken_token_user_id_35299eff_fk_map_userprofile_id` FOREIGN KEY (`user_id`) REFERENCES `map_userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authtoken_token`
--

LOCK TABLES `authtoken_token` WRITE;
/*!40000 ALTER TABLE `authtoken_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `authtoken_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_map_userprofile_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_map_userprofile_id` FOREIGN KEY (`user_id`) REFERENCES `map_userprofile` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(16,'authtoken','token'),(17,'authtoken','tokenproxy'),(4,'contenttypes','contenttype'),(6,'map','cable'),(12,'map','client'),(10,'map','connection'),(9,'map','core'),(11,'map','gpon'),(7,'map','marker'),(13,'map','pop'),(14,'map','reseller'),(15,'map','tjbox'),(8,'map','userprofile'),(5,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (1,'contenttypes','0001_initial','2024-03-29 12:02:20.448080'),(2,'contenttypes','0002_remove_content_type_name','2024-03-29 12:02:20.455225'),(3,'auth','0001_initial','2024-03-29 12:02:20.484051'),(4,'auth','0002_alter_permission_name_max_length','2024-03-29 12:02:20.491735'),(5,'auth','0003_alter_user_email_max_length','2024-03-29 12:02:20.493394'),(6,'auth','0004_alter_user_username_opts','2024-03-29 12:02:20.495089'),(7,'auth','0005_alter_user_last_login_null','2024-03-29 12:02:20.496736'),(8,'auth','0006_require_contenttypes_0002','2024-03-29 12:02:20.497046'),(9,'auth','0007_alter_validators_add_error_messages','2024-03-29 12:02:20.499066'),(10,'auth','0008_alter_user_username_max_length','2024-03-29 12:02:20.500597'),(11,'auth','0009_alter_user_last_name_max_length','2024-03-29 12:02:20.502200'),(12,'auth','0010_alter_group_name_max_length','2024-03-29 12:02:20.505330'),(13,'auth','0011_update_proxy_permissions','2024-03-29 12:02:20.508296'),(14,'auth','0012_alter_user_first_name_max_length','2024-03-29 12:02:20.510762'),(15,'map','0001_initial','2024-03-29 12:02:20.658496'),(16,'admin','0001_initial','2024-03-29 12:02:20.674993'),(17,'admin','0002_logentry_remove_auto_add','2024-03-29 12:02:20.677807'),(18,'admin','0003_logentry_add_action_flag_choices','2024-03-29 12:02:20.681025'),(19,'authtoken','0001_initial','2024-03-29 12:02:20.689777'),(20,'authtoken','0002_auto_20160226_1747','2024-03-29 12:02:20.698958'),(21,'authtoken','0003_tokenproxy','2024-03-29 12:02:20.699539'),(22,'sessions','0001_initial','2024-03-29 12:02:20.703967');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_cable`
--

DROP TABLE IF EXISTS `map_cable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_cable` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `identifier` varchar(100) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `start_from` varchar(100) NOT NULL,
  `end_to` varchar(100) NOT NULL,
  `number_of_cores` int NOT NULL,
  `length` double DEFAULT NULL,
  `notes` longtext,
  `description` longtext,
  `polyline` longtext,
  `ending_point_id` bigint NOT NULL,
  `starting_point_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `map_cable_ending_point_id_bd56b00f_fk_map_marker_id` (`ending_point_id`),
  KEY `map_cable_starting_point_id_ff7dca29_fk_map_marker_id` (`starting_point_id`),
  CONSTRAINT `map_cable_ending_point_id_bd56b00f_fk_map_marker_id` FOREIGN KEY (`ending_point_id`) REFERENCES `map_marker` (`id`),
  CONSTRAINT `map_cable_starting_point_id_ff7dca29_fk_map_marker_id` FOREIGN KEY (`starting_point_id`) REFERENCES `map_marker` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_cable`
--

LOCK TABLES `map_cable` WRITE;
/*!40000 ALTER TABLE `map_cable` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_cable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_client`
--

DROP TABLE IF EXISTS `map_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_client` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `identifier` varchar(100) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `mobile_number` varchar(100) DEFAULT NULL,
  `marker_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `marker_id` (`marker_id`),
  CONSTRAINT `map_client_marker_id_a667b8d2_fk_map_marker_id` FOREIGN KEY (`marker_id`) REFERENCES `map_marker` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_client`
--

LOCK TABLES `map_client` WRITE;
/*!40000 ALTER TABLE `map_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_connection`
--

DROP TABLE IF EXISTS `map_connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_connection` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `core_from_id` bigint NOT NULL,
  `core_to_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `map_connection_core_from_id_6abb8c1f_fk_map_core_id` (`core_from_id`),
  KEY `map_connection_core_to_id_03378b8d_fk_map_core_id` (`core_to_id`),
  CONSTRAINT `map_connection_core_from_id_6abb8c1f_fk_map_core_id` FOREIGN KEY (`core_from_id`) REFERENCES `map_core` (`id`),
  CONSTRAINT `map_connection_core_to_id_03378b8d_fk_map_core_id` FOREIGN KEY (`core_to_id`) REFERENCES `map_core` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_connection`
--

LOCK TABLES `map_connection` WRITE;
/*!40000 ALTER TABLE `map_connection` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_connection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_core`
--

DROP TABLE IF EXISTS `map_core`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_core` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `core_number` int NOT NULL,
  `color` varchar(100) NOT NULL,
  `assigned` tinyint(1) NOT NULL,
  `cable_id` bigint DEFAULT NULL,
  `splitter_id` bigint DEFAULT NULL,
  `marker_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `map_core_splitter_id_5c8af8a9_fk_map_gpon_id` (`splitter_id`),
  KEY `map_core_marker_id_19f60369_fk_map_marker_id` (`marker_id`),
  KEY `map_core_cable_id_9ba1e7d8_fk_map_cable_id` (`cable_id`),
  CONSTRAINT `map_core_cable_id_9ba1e7d8_fk_map_cable_id` FOREIGN KEY (`cable_id`) REFERENCES `map_cable` (`id`),
  CONSTRAINT `map_core_marker_id_19f60369_fk_map_marker_id` FOREIGN KEY (`marker_id`) REFERENCES `map_marker` (`id`),
  CONSTRAINT `map_core_splitter_id_5c8af8a9_fk_map_gpon_id` FOREIGN KEY (`splitter_id`) REFERENCES `map_gpon` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_core`
--

LOCK TABLES `map_core` WRITE;
/*!40000 ALTER TABLE `map_core` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_core` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_gpon`
--

DROP TABLE IF EXISTS `map_gpon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_gpon` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `identifier` varchar(100) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `splitter` int NOT NULL,
  `input_cable_id` bigint DEFAULT NULL,
  `input_core_id` bigint DEFAULT NULL,
  `marker_id` bigint NOT NULL,
  `tj_box_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `map_gpon_tj_box_id_8860f4ae_fk_map_tjbox_id` (`tj_box_id`),
  KEY `map_gpon_input_cable_id_7644f3a3_fk_map_cable_id` (`input_cable_id`),
  KEY `map_gpon_input_core_id_e0254cc5_fk_map_core_id` (`input_core_id`),
  KEY `map_gpon_marker_id_c129dd68_fk_map_marker_id` (`marker_id`),
  CONSTRAINT `map_gpon_input_cable_id_7644f3a3_fk_map_cable_id` FOREIGN KEY (`input_cable_id`) REFERENCES `map_cable` (`id`),
  CONSTRAINT `map_gpon_input_core_id_e0254cc5_fk_map_core_id` FOREIGN KEY (`input_core_id`) REFERENCES `map_core` (`id`),
  CONSTRAINT `map_gpon_marker_id_c129dd68_fk_map_marker_id` FOREIGN KEY (`marker_id`) REFERENCES `map_marker` (`id`),
  CONSTRAINT `map_gpon_tj_box_id_8860f4ae_fk_map_tjbox_id` FOREIGN KEY (`tj_box_id`) REFERENCES `map_tjbox` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_gpon`
--

LOCK TABLES `map_gpon` WRITE;
/*!40000 ALTER TABLE `map_gpon` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_gpon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_marker`
--

DROP TABLE IF EXISTS `map_marker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_marker` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `identifier` varchar(100) DEFAULT NULL,
  `type` varchar(100) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `notes` longtext,
  `description` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_marker`
--

LOCK TABLES `map_marker` WRITE;
/*!40000 ALTER TABLE `map_marker` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_marker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_pop`
--

DROP TABLE IF EXISTS `map_pop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_pop` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `identifier` varchar(100) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `pop_type` varchar(100) NOT NULL,
  `marker_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `marker_id` (`marker_id`),
  CONSTRAINT `map_pop_marker_id_9563816b_fk_map_marker_id` FOREIGN KEY (`marker_id`) REFERENCES `map_marker` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_pop`
--

LOCK TABLES `map_pop` WRITE;
/*!40000 ALTER TABLE `map_pop` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_pop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_reseller`
--

DROP TABLE IF EXISTS `map_reseller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_reseller` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `identifier` varchar(100) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `mobile_number` varchar(100) DEFAULT NULL,
  `marker_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `marker_id` (`marker_id`),
  CONSTRAINT `map_reseller_marker_id_11f2ca3b_fk_map_marker_id` FOREIGN KEY (`marker_id`) REFERENCES `map_marker` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_reseller`
--

LOCK TABLES `map_reseller` WRITE;
/*!40000 ALTER TABLE `map_reseller` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_reseller` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_tjbox`
--

DROP TABLE IF EXISTS `map_tjbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_tjbox` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `identifier` varchar(100) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `marker_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `marker_id` (`marker_id`),
  CONSTRAINT `map_tjbox_marker_id_6c7454ae_fk_map_marker_id` FOREIGN KEY (`marker_id`) REFERENCES `map_marker` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_tjbox`
--

LOCK TABLES `map_tjbox` WRITE;
/*!40000 ALTER TABLE `map_tjbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_tjbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_userprofile`
--

DROP TABLE IF EXISTS `map_userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_userprofile` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `biography` longtext,
  `contact_number` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_userprofile`
--

LOCK TABLES `map_userprofile` WRITE;
/*!40000 ALTER TABLE `map_userprofile` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_userprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_userprofile_groups`
--

DROP TABLE IF EXISTS `map_userprofile_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_userprofile_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userprofile_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `map_userprofile_groups_userprofile_id_group_id_876fb059_uniq` (`userprofile_id`,`group_id`),
  KEY `map_userprofile_groups_group_id_7ffca625_fk_auth_group_id` (`group_id`),
  CONSTRAINT `map_userprofile_grou_userprofile_id_f1731c64_fk_map_userp` FOREIGN KEY (`userprofile_id`) REFERENCES `map_userprofile` (`id`),
  CONSTRAINT `map_userprofile_groups_group_id_7ffca625_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_userprofile_groups`
--

LOCK TABLES `map_userprofile_groups` WRITE;
/*!40000 ALTER TABLE `map_userprofile_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_userprofile_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_userprofile_user_permissions`
--

DROP TABLE IF EXISTS `map_userprofile_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map_userprofile_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userprofile_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `map_userprofile_user_per_userprofile_id_permissio_8ebc5d7f_uniq` (`userprofile_id`,`permission_id`),
  KEY `map_userprofile_user_permission_id_4a85c20b_fk_auth_perm` (`permission_id`),
  CONSTRAINT `map_userprofile_user_permission_id_4a85c20b_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `map_userprofile_user_userprofile_id_1763bc82_fk_map_userp` FOREIGN KEY (`userprofile_id`) REFERENCES `map_userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_userprofile_user_permissions`
--

LOCK TABLES `map_userprofile_user_permissions` WRITE;
/*!40000 ALTER TABLE `map_userprofile_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_userprofile_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'noakhal1_fiberMap'
--

--
-- Dumping routines for database 'noakhal1_fiberMap'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-30  7:38:11
